# appdirect-code-challenge-solution

<%- description %>

## Setup

Install the project dependencies:

`npm install`

## Running

Starts the static and proxy servers:

`npm start`

