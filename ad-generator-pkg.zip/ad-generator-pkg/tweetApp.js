/**
 * @author Rupesh Malusare
 * @since Sept. 30, 2016
 *
 */
(function(window) {
	"use strict"
	angular.module("tweetApp",['ui.stepper'])
    .config(tweetConfig)
    .run(tweetRun);

    tweetConfig.$inject=[]
    function tweetConfig () {
        
    }
    tweetRun.$inject=[]
    function tweetRun () {
        
    }
}(window));

